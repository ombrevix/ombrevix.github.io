using System.Collections.Generic;
using System.Text.Json.Serialization;
using OmbrevixBilling.Core.Models;
using OmbrevixBilling.Models.Enums;

namespace OmbrevixBilling.Models;

/// <summary>
/// Warning: When updating a datafield's scope attribute, all scope attributes must be passed. Partially complete scope attributes will override the existing settings.
/// </summary>
public record DatafieldScope
{
    /// <summary>
    /// Include (1) or exclude (0) datafields from the csv export.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("csv")]
    public IncludeOption? Csv { get; init; }

    /// <summary>
    /// Include (1) or exclude (0) datafields from invoices.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("invoices")]
    public IncludeOption? Invoices { get; init; }

    /// <summary>
    /// Include (1) or exclude (0) datafields from statements.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("statements")]
    public IncludeOption? Statements { get; init; }

    /// <summary>
    /// Include (1) or exclude (0) datafields from the portal.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("portal")]
    public IncludeOption? Portal { get; init; }

    /// <summary>
    /// Include (1) or exclude (0) datafields used in Embeddable Addons from being viewable by your ecosystem.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("public_show")]
    public IncludeOption? PublicShow { get; init; }

    /// <summary>
    /// Include (1) or exclude (0) datafields used in Embeddable Addons from being editable by your ecosystem.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("public_edit")]
    public IncludeOption? PublicEdit { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("hosted")]
    public IReadOnlyList<string>? Hosted { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
